# docs

Role: Contributor and operator documentation

Keep quickstart, behavior, repair guidance, and release notes aligned with observed code.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
