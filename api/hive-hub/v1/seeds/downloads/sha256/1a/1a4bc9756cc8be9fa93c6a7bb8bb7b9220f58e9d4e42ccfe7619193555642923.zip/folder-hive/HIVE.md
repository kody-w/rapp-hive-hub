---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The Open-Source Infrastructure Foundation

A folder-Hive template made from the RAPP Hive Hub starter `open-source-infrastructure-foundation`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[open-source-infrastructure-foundation]]
- First case: [[line-ledger-repair-cycle]]
- Rooms: `shared/maintainers/`, `shared/triage/`, `shared/engineering/`, `shared/security/`, `shared/docs/`, `shared/release/`, `shared/community/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
