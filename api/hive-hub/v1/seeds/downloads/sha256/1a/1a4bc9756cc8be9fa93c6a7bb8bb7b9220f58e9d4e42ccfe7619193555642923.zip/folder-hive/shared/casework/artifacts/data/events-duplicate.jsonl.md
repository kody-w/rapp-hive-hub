---
seed_file: templates/casework/work/starter/data/events-duplicate.jsonl
seed_sha256: 209a05fc4bc3c8582e966d471200397521c9a1592b75820c5ef9439697247de3
---

```
{"classification":"SYNTHETIC","event_id":"event-a-open","item_id":"item-a","action":"open","at_minute":10}
{"classification":"SYNTHETIC","event_id":"event-a-open","item_id":"item-a","action":"open","at_minute":10}
{"classification":"SYNTHETIC","event_id":"event-a-close","item_id":"item-a","action":"close","at_minute":20}
{"classification":"SYNTHETIC","event_id":"event-b-open","item_id":"item-b","action":"open","at_minute":15}
```
