---
seed_file: templates/casework/work/starter/refs/handshake-panel.svg
seed_sha256: f16ec9242a4bfeb8f5211c055567ca9bbbc88daf385440373e36eec10312874d
---

```
<svg xmlns="http://www.w3.org/2000/svg" width="960" height="420" viewBox="0 0 960 420">
  <title>Reference: server answer panel (ui-panel effect)</title>
  <desc>Rows arrive one by one and their check marks settle; the status pill lands last with a short glow. Brand: studio house kit.</desc>
  <rect x="0" y="0" width="960" height="420" rx="36" fill="#0B0B0F"/>
  <rect x="1.5" y="1.5" width="957" height="417" rx="34.5" fill="none" stroke="#2A2A35" stroke-width="3"/>
  <text x="48" y="78" font-family="Inter, sans-serif" font-size="30" font-weight="700" fill="#F7F5F0">Server</text>
  <text x="48" y="112" font-family="Inter, sans-serif" font-size="22" fill="#9A98A6">answers the upgrade</text>
  <rect x="560" y="44" width="352" height="64" rx="32" fill="#00D1B2"/>
  <text x="736" y="86" text-anchor="middle" font-family="Inter, sans-serif" font-size="26" font-weight="700" fill="#0B0B0F">101 Switching Protocols</text>
  <g font-family="JetBrains Mono, monospace" font-size="26" fill="#F7F5F0">
    <rect x="48" y="150" width="864" height="64" rx="16" fill="#16161D"/>
    <circle cx="86" cy="182" r="14" fill="#5B4BFF"/><path d="M79 182 l5 6 l10 -12" stroke="#F7F5F0" stroke-width="4" fill="none"/>
    <text x="116" y="191">Upgrade: websocket</text>
    <rect x="48" y="226" width="864" height="64" rx="16" fill="#16161D"/>
    <circle cx="86" cy="258" r="14" fill="#5B4BFF"/><path d="M79 258 l5 6 l10 -12" stroke="#F7F5F0" stroke-width="4" fill="none"/>
    <text x="116" y="267">Connection: Upgrade</text>
    <rect x="48" y="302" width="864" height="64" rx="16" fill="#16161D"/>
    <circle cx="86" cy="334" r="14" fill="#5B4BFF"/><path d="M79 334 l5 6 l10 -12" stroke="#F7F5F0" stroke-width="4" fill="none"/>
    <text x="116" y="343" font-size="24">Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=</text>
  </g>
</svg>
```
