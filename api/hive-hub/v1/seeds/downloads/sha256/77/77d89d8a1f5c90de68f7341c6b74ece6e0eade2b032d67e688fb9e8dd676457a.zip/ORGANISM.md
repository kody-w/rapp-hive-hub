# Where this fits: The AI Video Studio

This package is a RAPP Work starter: synthetic public files that you read as data. It is not an activated organization, a Hive, a membership or a running service, and it grants no authority.

## The stack, bottom to top

| # | Layer | Health | What this starter touches |
| --- | --- | --- | --- |
| 0 | RAPP/1 | in force | Its plans mint RAPP/1 RAPPIDs with the pinned reference (kody-w/rapp-1 at 591e014). The package itself holds no RAPPID, key or signature. |
| 1 | Estate | in force | Nothing: no registry entry, owner key or signature is included, and initialize.json says signed_estate_activation: false. |
| 2 | Organization | specified | An Organization plan: one owner you choose, one world (ai-video-studio), 9 teams and one case. Canonical rapp-work/1 is specified; no estate has activated it yet (G16), and it cannot bind a folder Hive yet (G10). The SDK Organization that initialize.json plans is a pointer-only routing object (G11 proposes calling it a workspace index), not an activated organization. |
| 3 | Hive | in force: rapp-hive/1 Private Hive · experimental: folder Hive | Today the one Hive an organization can hold is a rapp-hive/1 Private Hive; this package declares none, and its owner would create one under rapp-hive/1. Experimental option: the folder-Hive template in folder-hive/, which a founder's Brainstem creates with the Hive agent. |
| 4 | Your device | in force: workspaces · experimental: Hive copies, references | Each member's scoped Workspaces from templates/ (9 teams plus casework), planned with the pinned RAPP Work SDK (kody-w/rapp-work at 29ead23). The unzipped package is a reference: read as data, brought into a Hive only by signed copy. |
| 5 | Brainstem | in force | The boot Egg hatches a Brainstem with the SeedRunner organ (experimental), which runs the same SDK flow; the Hive agent, one file in a Brainstem, creates a folder Hive from the template. |
| 6 | You | — | You choose the owner label and destination, and confirm every exact plan in a later turn. |

Across: Hive Mind (candidate). Hive Hub finds and joins across Hives. This starter's Dial Record and join cards describe the package, not a live Hive; dial records do not describe folder Hives yet (G12). Transport carries; signatures decide.

`rapp-hive/2` is frozen as a research record; nothing here uses it.

## Pull it down as a reference

Download the ZIP, check its SHA-256 against the seed page, and unzip it into a new folder. That folder, like the seed folder in the repository, is a reference in its own shape: read-only, never run, and read as data. Nothing moves into a Hive until a member brings a piece of it in by one signed commit, stamped with `brought_from` and `brought_sha256`. The hive-network skill verifies the package first and never runs it.

## Create the folder Hive (experimental)

`folder-hive/` is an inert template in the Hive folder convention. It holds `HIVE.md`, `.gitattributes` and 10 rooms under `shared/`: one note per task (with `id`, `title`, `status` and `depends_on`, linked by `[[id]]`), the charter and case intake, and the starter files as notes in `shared/casework/artifacts/`.

1. Ask your Brainstem to create a Hive with the Hive agent: `create` with this starter's name as its title, `approvals` 2, and the `fields` hint from `folder-hive/HIVE.md`. The Hive agent writes `HIVE.md` with a fresh `hive:` id, the `.gitattributes` file and your signed key file.
2. Pin the unzipped folder as a reference (`reference`), then bring each room by signed copy: `bring` from `folder-hive/shared/<room>` to `shared/<room>`. Each proposal shows who will see the files; nothing applies until you confirm it in a later turn.
3. Invite people. Each person's Brainstem files one signed request; members admit them with the Hive's approvals.

An organization cannot bind a folder Hive yet (G10), so this Hive stays beside the Organization plan, not inside it.

## How the starter maps

- 14 of 23 starter files are not markdown, so they sit in `shared/casework/artifacts/` as fenced markdown notes named `<file>.md`; `seed_file` and `seed_sha256` name the exact package file. In a Hive they are data: run or edit the originals from the ZIP or a workspace.
- Task outputs are logical `deliverables/` paths. A folder Hive holds only markdown, so a team adds each finished output as a note (or keeps it in a workspace); the template creates none.
- The demonstration world id has no folder-Hive counterpart: a folder Hive has its own random `hive:` id and no world. The seed's unassigned tasks have no `owner` until a member claims one.

Maps: [ECOSYSTEM.md](https://github.com/kody-w/rapp-work/blob/experimental/rapp-work-constitution/ECOSYSTEM.md) and [CONSTITUTION.md](https://github.com/kody-w/rapp-work/blob/experimental/rapp-work-constitution/CONSTITUTION.md) (kody-w/rapp-work, experimental), and the [Hive folder convention](https://github.com/kody-w/rapp-model-hive/blob/experimental/hive-md/HIVE-MD.md) (kody-w/rapp-model-hive, experimental). Specifications decide; this page only points at them.
