---
seed_file: templates/casework/work/starter/project/typing-window.html
seed_sha256: 8ab71565d4b00ca02eff1be6488365040835a1b5f5599f443d757df6e4c25651
---

```
<!--
  typing-window: a request, command or chat typed out at speaking pace in a window placed in empty space.
  HyperFrames sub-composition. Host it from your root index.html, for example:
    <div id="el-typing" class="scene" data-composition-id="typing-window" data-composition-src="compositions/overlays/typing-window.html"
         data-start="9.2" data-duration="8" data-track-index="31"></div>
  Edit CONFIG below. Times are seconds from this overlay's own start; take them from the transcript so each line starts
  when it is spoken (CONFIG.lines[i].at). Keep CONFIG.duration equal to the host's data-duration.
  Seek-safe: every character is revealed by a timeline set at a fixed time, so any frame renders on its own.
  Expects GSAP at assets/vendor/gsap.min.js. For a second copy, change the composition id in both places.
-->
<template id="typing-window-template">
  <script src="assets/vendor/gsap.min.js"></script>
  <style>
    #typing-window-root {
      position: absolute;
      inset: 0;
      pointer-events: none;
    }
    #typing-window-root .box {
      position: absolute;
      left: var(--zone-lower-x, 60px);
      top: var(--zone-lower-y, 1250px);
      width: var(--zone-lower-w, 870px);
      height: var(--zone-lower-h, 380px);
      box-sizing: border-box;
      border-radius: 28px;
      background: var(--paper, #f7f5f0);
      border: 3px solid #d9d5cc;
      box-shadow: 0 18px 50px rgba(11, 11, 15, 0.35);
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
    }
    #typing-window-root .bar {
      height: 56px;
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 0 22px;
      border-bottom: 2px solid #d9d5cc;
    }
    #typing-window-root .dot { width: 16px; height: 16px; border-radius: 50%; }
    #typing-window-root .title {
      margin-left: auto;
      margin-right: auto;
      font-family: var(--font-body, "Inter", system-ui, sans-serif);
      font-weight: 700;
      font-size: 20px;
      color: #5e5b66;
    }
    #typing-window-root .code {
      padding: 18px 26px;
      font-family: var(--font-mono, "JetBrains Mono", ui-monospace, monospace);
      font-size: 25px;
      line-height: 1.45;
      color: var(--ink, #0b0b0f);
      white-space: pre;
    }
    #typing-window-root .line.hl { color: var(--signal, #5b4bff); font-weight: 700; }
    #typing-window-root .ch { position: relative; opacity: 0; }
    #typing-window-root .cur {
      position: absolute;
      left: 100%;
      top: 50%;
      width: 13px;
      height: 28px;
      margin: -15px 0 0 1px;
      background: var(--signal, #5b4bff);
      opacity: 0;
    }
  </style>
  <div id="typing-window-root" data-composition-id="typing-window" data-width="1080" data-height="1920">
    <div class="box" data-zone="lower">
    <div class="bar">
      <span class="dot" style="background: var(--warn, #ff5a36)"></span>
      <span class="dot" style="background: #e8b931"></span>
      <span class="dot" style="background: var(--pulse, #00d1b2)"></span>
      <span class="title" id="typing-window-title"></span>
    </div>
    <div class="code" id="typing-window-code"></div>
  </div>
  </div>
  <script>
    (function () {
      var CONFIG = {
        duration: 8.0,
        title: "client \u2192 server",
        charsPerSecond: 26,
        lines: [
          { text: "GET /chat HTTP/1.1", at: 0.5 },
          { text: "Host: server.example.com", at: 1.3 },
          { text: "Upgrade: websocket", at: 2.3, highlightAt: 2.9 },
          { text: "Connection: Upgrade", at: 3.2, highlightAt: 3.8 },
          { text: "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==", at: 4.3 },
          { text: "Sec-WebSocket-Version: 13", at: 6.0 }
        ],
        exitAt: 7.7
      };
      document.getElementById("typing-window-title").textContent = CONFIG.title;
      var code = document.getElementById("typing-window-code");
      var tl = gsap.timeline({ paused: true });
      tl.fromTo("#typing-window-root .box", { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.45, ease: "power3.out" }, 0);
      var lastCursor = null;
      var lastTime = 0;
      CONFIG.lines.forEach(function (line, li) {
        var row = document.createElement("div");
        row.className = "line";
        row.id = "typing-window-line-" + li;
        code.appendChild(row);
        for (var ci = 0; ci < line.text.length; ci++) {
          var ch = document.createElement("span");
          ch.className = "ch";
          ch.textContent = line.text[ci];
          row.appendChild(ch);
          var cur = document.createElement("span");
          cur.className = "cur";
          ch.appendChild(cur);
          var t = line.at + ci / CONFIG.charsPerSecond;
          tl.set(ch, { opacity: 1 }, t);
          tl.set(cur, { opacity: 1 }, t);
          if (lastCursor) tl.set(lastCursor, { opacity: 0 }, t);
          lastCursor = cur;
          lastTime = t;
        }
        if (line.highlightAt !== undefined) tl.set(row, { className: "line hl" }, line.highlightAt);
      });
      for (var b = lastTime + 0.5, on = false; b < CONFIG.exitAt; b += 0.5, on = !on) tl.set(lastCursor, { opacity: on ? 1 : 0 }, b);
      tl.to("#typing-window-root .box", { opacity: 0, y: 20, duration: CONFIG.duration - CONFIG.exitAt, ease: "power2.in" }, CONFIG.exitAt);
      tl.to({}, { duration: CONFIG.duration }, 0);
      window.__timelines = window.__timelines || {};
      window.__timelines["typing-window"] = tl;
    })();
  </script>
</template>
```
