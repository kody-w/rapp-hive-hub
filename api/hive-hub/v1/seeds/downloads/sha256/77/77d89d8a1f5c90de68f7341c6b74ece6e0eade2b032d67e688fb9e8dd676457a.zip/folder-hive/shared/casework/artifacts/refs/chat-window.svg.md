---
seed_file: templates/casework/work/starter/refs/chat-window.svg
seed_sha256: 6776663ad12d0bf90a304e4e0ce4c581a3a199e14f8a5988bc4d64c2b43ca9c5
---

```
<svg xmlns="http://www.w3.org/2000/svg" width="960" height="520" viewBox="0 0 960 520">
  <title>Reference: live-typing request window (typing-window effect)</title>
  <desc>The window slides into empty space, then each line types out at speaking pace with a blinking cursor; the Upgrade lines take the signal colour as they are spoken. Brand: studio house kit.</desc>
  <rect x="0" y="0" width="960" height="520" rx="32" fill="#F7F5F0"/>
  <rect x="1.5" y="1.5" width="957" height="517" rx="30.5" fill="none" stroke="#D9D5CC" stroke-width="3"/>
  <circle cx="44" cy="44" r="10" fill="#FF5A36"/><circle cx="76" cy="44" r="10" fill="#E8B931"/><circle cx="108" cy="44" r="10" fill="#00D1B2"/>
  <text x="480" y="52" text-anchor="middle" font-family="Inter, sans-serif" font-size="22" font-weight="700" fill="#5E5B66">client → server</text>
  <line x1="0" y1="84" x2="960" y2="84" stroke="#D9D5CC" stroke-width="2"/>
  <g font-family="JetBrains Mono, monospace" font-size="28" fill="#0B0B0F">
    <text x="44" y="140">GET /chat HTTP/1.1</text>
    <text x="44" y="190">Host: server.example.com</text>
    <text x="44" y="240" fill="#5B4BFF" font-weight="700">Upgrade: websocket</text>
    <text x="44" y="290" fill="#5B4BFF" font-weight="700">Connection: Upgrade</text>
    <text x="44" y="340">Sec-WebSocket-Key:</text>
    <text x="44" y="384" font-size="26">  dGhlIHNhbXBsZSBub25jZQ==</text>
    <text x="44" y="434">Sec-WebSocket-Version: 13</text>
  </g>
  <rect x="480" y="410" width="16" height="32" fill="#5B4BFF"/>
</svg>
```
