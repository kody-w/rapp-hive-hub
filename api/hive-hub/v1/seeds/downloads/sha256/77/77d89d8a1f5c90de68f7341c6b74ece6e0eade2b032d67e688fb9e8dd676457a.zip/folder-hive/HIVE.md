---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The AI Video Studio

A folder-Hive template made from the RAPP Hive Hub starter `ai-video-studio`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[ai-video-studio]]
- First case: [[pilot-websocket-short]]
- Rooms: `shared/showrunner/`, `shared/brand/`, `shared/transcription/`, `shared/motion-board/`, `shared/motion-graphics/`, `shared/captions/`, `shared/explainers/`, `shared/quality/`, `shared/release/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
