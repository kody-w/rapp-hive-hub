---
seed_file: templates/casework/work/starter/brand/tokens.json
seed_sha256: ca62849805d535facfaf60cac55a3e81630140881ca301b8224c8682e359bc27
---

```
{
  "schema": "studio-brand-kit/1",
  "name": "house",
  "display_name": "Studio house kit",
  "colors": {
    "ink": "#0B0B0F",
    "paper": "#F7F5F0",
    "signal": "#5B4BFF",
    "pulse": "#00D1B2",
    "warn": "#FF5A36",
    "muted": "#9A98A6",
    "panel": "#16161D",
    "line": "#2A2A35"
  },
  "fonts": {
    "display": { "family": "Inter", "weight": 700, "file": "fonts/Inter-700.woff2" },
    "body": { "family": "Inter", "weight": 400, "file": "fonts/Inter-400.woff2" },
    "kicker": { "family": "EB Garamond", "weight": 400, "file": "fonts/EBGaramond-400.woff2" },
    "mono": { "family": "JetBrains Mono", "weight": 400, "file": "fonts/JetBrainsMono-400.woff2" },
    "mono_bold": { "family": "JetBrains Mono", "weight": 700, "file": "fonts/JetBrainsMono-700.woff2" }
  },
  "frame": { "width": 1080, "height": 1920, "fps": 30 },
  "zones": {
    "face": [240, 300, 600, 700],
    "top": [60, 80, 960, 200],
    "caption": [90, 1040, 840, 200],
    "lower": [60, 1250, 870, 380],
    "left": [40, 330, 180, 550],
    "right": [860, 330, 180, 550]
  },
  "platform_safe": {
    "bottom_y": 1640,
    "right_rail": [950, 900, 130, 740],
    "why": "Short-video platforms draw their own text along the bottom and buttons down the right; keep words out of both."
  },
  "captions": {
    "max_words": 4,
    "max_lines": 2,
    "punctuation": false,
    "case": "sentence",
    "size_px": 76,
    "weight": 700,
    "color": "paper",
    "active": "signal",
    "shadow": "0 4px 18px rgba(11, 11, 15, 0.55)"
  },
  "motion": {
    "enter_ease": "power3.out",
    "exit_ease": "power2.in",
    "enter_s": [0.35, 0.6],
    "min_read_s": 1.2,
    "forbidden": ["bounce", "elastic", "spin", "rainbow gradients"]
  },
  "logo": null
}
```
