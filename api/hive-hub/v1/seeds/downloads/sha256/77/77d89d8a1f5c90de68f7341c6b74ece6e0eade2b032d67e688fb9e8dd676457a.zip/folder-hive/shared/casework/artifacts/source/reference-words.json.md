---
seed_file: templates/casework/work/starter/source/reference-words.json
seed_sha256: 8b7163df6fc7626a1accc3b402d0cf3d905329b98a98e464a9703ce61974b144
---

```
{
 "schema": "studio-words/1",
 "engine": "reference-read",
 "model": "synthesized two-voice narration of source/script.md, forced word alignment",
 "source": "reference read (not included; produce your own take)",
 "window": null,
 "language": "en",
 "note": "Real word timings from the studio's synthesized reference read of script.md, on that read's own timeline (two windows: 0.3-16.39 s and 20.8-48.7 s; the agenda line between them is not in the script). Use it to plan pacing before your take exists; the board and captions must use your take's transcript.",
 "words": [
  {
   "speaker": "ADA",
   "text": "How",
   "start": 0.56,
   "end": 0.68
  },
  {
   "speaker": "ADA",
   "text": "did",
   "start": 0.68,
   "end": 0.91
  },
  {
   "speaker": "ADA",
   "text": "web",
   "start": 0.91,
   "end": 1.53
  },
  {
   "speaker": "ADA",
   "text": "pages",
   "start": 1.53,
   "end": 1.57
  },
  {
   "speaker": "ADA",
   "text": "get",
   "start": 1.57,
   "end": 1.68
  },
  {
   "speaker": "ADA",
   "text": "live",
   "start": 1.86,
   "end": 2.07
  },
  {
   "speaker": "ADA",
   "text": "updates",
   "start": 2.07,
   "end": 2.62
  },
  {
   "speaker": "ADA",
   "text": "before",
   "start": 2.7,
   "end": 2.96
  },
  {
   "speaker": "ADA",
   "text": "WebSockets?",
   "start": 2.96,
   "end": 3.65
  },
  {
   "speaker": "MAX",
   "text": "By",
   "start": 3.966,
   "end": 4.086
  },
  {
   "speaker": "MAX",
   "text": "polling,",
   "start": 4.146,
   "end": 4.936
  },
  {
   "speaker": "MAX",
   "text": "which",
   "start": 4.986,
   "end": 5.336
  },
  {
   "speaker": "MAX",
   "text": "the",
   "start": 5.336,
   "end": 5.576
  },
  {
   "speaker": "MAX",
   "text": "WebSocket",
   "start": 5.576,
   "end": 6.236
  },
  {
   "speaker": "MAX",
   "text": "RFC",
   "start": 6.276,
   "end": 6.526
  },
  {
   "speaker": "MAX",
   "text": "calls",
   "start": 6.576,
   "end": 6.896
  },
  {
   "speaker": "MAX",
   "text": "an",
   "start": 6.896,
   "end": 7.066
  },
  {
   "speaker": "MAX",
   "text": "abuse",
   "start": 7.066,
   "end": 7.496
  },
  {
   "speaker": "MAX",
   "text": "of",
   "start": 7.496,
   "end": 7.936
  },
  {
   "speaker": "MAX",
   "text": "HTTP.",
   "start": 7.936,
   "end": 8.756
  },
  {
   "speaker": "MAX",
   "text": "RFC",
   "start": 8.894,
   "end": 9.284
  },
  {
   "speaker": "MAX",
   "text": "6455",
   "start": 9.284,
   "end": 10.894
  },
  {
   "speaker": "MAX",
   "text": "offers",
   "start": 11.124,
   "end": 11.614
  },
  {
   "speaker": "MAX",
   "text": "one",
   "start": 11.614,
   "end": 11.894
  },
  {
   "speaker": "MAX",
   "text": "TCP",
   "start": 11.894,
   "end": 12.174
  },
  {
   "speaker": "MAX",
   "text": "connection",
   "start": 12.174,
   "end": 13.164
  },
  {
   "speaker": "MAX",
   "text": "instead,",
   "start": 13.164,
   "end": 13.984
  },
  {
   "speaker": "MAX",
   "text": "carrying",
   "start": 14.164,
   "end": 14.564
  },
  {
   "speaker": "MAX",
   "text": "traffic",
   "start": 14.564,
   "end": 15.034
  },
  {
   "speaker": "MAX",
   "text": "in",
   "start": 15.114,
   "end": 15.214
  },
  {
   "speaker": "MAX",
   "text": "both",
   "start": 15.214,
   "end": 15.494
  },
  {
   "speaker": "MAX",
   "text": "directions.",
   "start": 15.524,
   "end": 16.244
  },
  {
   "speaker": "ADA",
   "text": "So",
   "start": 21.209,
   "end": 21.239
  },
  {
   "speaker": "ADA",
   "text": "how",
   "start": 21.239,
   "end": 21.409
  },
  {
   "speaker": "ADA",
   "text": "does",
   "start": 21.409,
   "end": 21.629
  },
  {
   "speaker": "ADA",
   "text": "a",
   "start": 21.629,
   "end": 21.679
  },
  {
   "speaker": "ADA",
   "text": "WebSocket",
   "start": 21.679,
   "end": 22.189
  },
  {
   "speaker": "ADA",
   "text": "connection",
   "start": 22.189,
   "end": 22.709
  },
  {
   "speaker": "ADA",
   "text": "start?",
   "start": 22.759,
   "end": 23.139
  },
  {
   "speaker": "MAX",
   "text": "As",
   "start": 23.466,
   "end": 23.616
  },
  {
   "speaker": "MAX",
   "text": "an",
   "start": 23.616,
   "end": 23.826
  },
  {
   "speaker": "MAX",
   "text": "ordinary",
   "start": 23.826,
   "end": 24.666
  },
  {
   "speaker": "MAX",
   "text": "HTTP",
   "start": 24.666,
   "end": 25.086
  },
  {
   "speaker": "MAX",
   "text": "request",
   "start": 25.086,
   "end": 25.806
  },
  {
   "speaker": "MAX",
   "text": "that",
   "start": 25.886,
   "end": 26.006
  },
  {
   "speaker": "MAX",
   "text": "asks",
   "start": 26.046,
   "end": 26.366
  },
  {
   "speaker": "MAX",
   "text": "to",
   "start": 26.436,
   "end": 26.566
  },
  {
   "speaker": "MAX",
   "text": "upgrade:",
   "start": 26.566,
   "end": 27.666
  },
  {
   "speaker": "MAX",
   "text": "Upgrade",
   "start": 27.726,
   "end": 28.206
  },
  {
   "speaker": "MAX",
   "text": "websocket,",
   "start": 28.206,
   "end": 29.066
  },
  {
   "speaker": "MAX",
   "text": "Connection",
   "start": 29.066,
   "end": 29.706
  },
  {
   "speaker": "MAX",
   "text": "Upgrade.",
   "start": 29.706,
   "end": 30.212
  },
  {
   "speaker": "MAX",
   "text": "It",
   "start": 30.342,
   "end": 30.502
  },
  {
   "speaker": "MAX",
   "text": "adds",
   "start": 30.502,
   "end": 30.912
  },
  {
   "speaker": "MAX",
   "text": "a",
   "start": 30.912,
   "end": 31.012
  },
  {
   "speaker": "MAX",
   "text": "random",
   "start": 31.012,
   "end": 31.522
  },
  {
   "speaker": "MAX",
   "text": "key,",
   "start": 31.522,
   "end": 31.992
  },
  {
   "speaker": "MAX",
   "text": "and",
   "start": 31.992,
   "end": 32.182
  },
  {
   "speaker": "MAX",
   "text": "asks",
   "start": 32.182,
   "end": 32.432
  },
  {
   "speaker": "MAX",
   "text": "for",
   "start": 32.472,
   "end": 32.672
  },
  {
   "speaker": "MAX",
   "text": "protocol",
   "start": 32.672,
   "end": 33.242
  },
  {
   "speaker": "MAX",
   "text": "version",
   "start": 33.242,
   "end": 33.742
  },
  {
   "speaker": "MAX",
   "text": "13.",
   "start": 33.742,
   "end": 34.242
  },
  {
   "speaker": "ADA",
   "text": "And",
   "start": 34.473,
   "end": 34.553
  },
  {
   "speaker": "ADA",
   "text": "the",
   "start": 34.553,
   "end": 34.663
  },
  {
   "speaker": "ADA",
   "text": "server?",
   "start": 34.733,
   "end": 35.103
  },
  {
   "speaker": "MAX",
   "text": "If",
   "start": 35.426,
   "end": 35.576
  },
  {
   "speaker": "MAX",
   "text": "it",
   "start": 35.576,
   "end": 35.736
  },
  {
   "speaker": "MAX",
   "text": "accepts,",
   "start": 35.796,
   "end": 36.646
  },
  {
   "speaker": "MAX",
   "text": "it",
   "start": 36.686,
   "end": 36.786
  },
  {
   "speaker": "MAX",
   "text": "answers",
   "start": 36.786,
   "end": 37.296
  },
  {
   "speaker": "MAX",
   "text": "101,",
   "start": 37.296,
   "end": 37.966
  },
  {
   "speaker": "MAX",
   "text": "Switching",
   "start": 37.966,
   "end": 38.426
  },
  {
   "speaker": "MAX",
   "text": "Protocols,",
   "start": 38.426,
   "end": 39.186
  },
  {
   "speaker": "MAX",
   "text": "with",
   "start": 39.246,
   "end": 39.386
  },
  {
   "speaker": "MAX",
   "text": "an",
   "start": 39.386,
   "end": 39.466
  },
  {
   "speaker": "MAX",
   "text": "accept",
   "start": 39.466,
   "end": 39.786
  },
  {
   "speaker": "MAX",
   "text": "header.",
   "start": 39.876,
   "end": 40.266
  },
  {
   "speaker": "MAX",
   "text": "Any",
   "start": 40.454,
   "end": 40.654
  },
  {
   "speaker": "MAX",
   "text": "other",
   "start": 40.654,
   "end": 41.084
  },
  {
   "speaker": "MAX",
   "text": "status",
   "start": 41.084,
   "end": 41.554
  },
  {
   "speaker": "MAX",
   "text": "code,",
   "start": 41.584,
   "end": 41.674
  },
  {
   "speaker": "MAX",
   "text": "and",
   "start": 42.024,
   "end": 42.254
  },
  {
   "speaker": "MAX",
   "text": "HTTP",
   "start": 42.254,
   "end": 42.654
  },
  {
   "speaker": "MAX",
   "text": "semantics",
   "start": 42.654,
   "end": 43.524
  },
  {
   "speaker": "MAX",
   "text": "still",
   "start": 43.554,
   "end": 44.044
  },
  {
   "speaker": "MAX",
   "text": "apply.",
   "start": 44.044,
   "end": 44.604
  },
  {
   "speaker": "MAX",
   "text": "Then",
   "start": 44.736,
   "end": 45.036
  },
  {
   "speaker": "MAX",
   "text": "frames",
   "start": 45.036,
   "end": 45.566
  },
  {
   "speaker": "MAX",
   "text": "flow",
   "start": 45.566,
   "end": 45.826
  },
  {
   "speaker": "MAX",
   "text": "both",
   "start": 45.946,
   "end": 46.126
  },
  {
   "speaker": "MAX",
   "text": "ways,",
   "start": 46.276,
   "end": 46.346
  },
  {
   "speaker": "MAX",
   "text": "whenever",
   "start": 46.686,
   "end": 47.216
  },
  {
   "speaker": "MAX",
   "text": "either",
   "start": 47.216,
   "end": 47.636
  },
  {
   "speaker": "MAX",
   "text": "side",
   "start": 47.636,
   "end": 47.916
  },
  {
   "speaker": "MAX",
   "text": "wants.",
   "start": 47.916,
   "end": 48.296
  }
 ]
}
```
