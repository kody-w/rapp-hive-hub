# Case acceptance

- A 1080x1920 H.264 MP4 of 30 to 45 seconds renders from a clean checkout with a pinned HyperFrames CLI, and lint and check report zero errors.
- The hook is on screen by 0.5 seconds, holds at least 2.5 seconds, and matches the approved motion board.
- Every caption word traces to the take's words.json in order; phrases have one to four words and no punctuation, and none enters the face zone or the platform-safe areas.
- Every on-screen technical statement maps to a verified claim whose anchor matches the pinned RFC 6455 bytes; nothing new is asserted.
- The motion board was approved before the build started, and PROVENANCE.json records the script, claim ledger, corpus, board and approval hashes, the project commit and the CLI version.
- No upload, publication or other external effect occurs.

No reference artifact counts as completed work without review.
