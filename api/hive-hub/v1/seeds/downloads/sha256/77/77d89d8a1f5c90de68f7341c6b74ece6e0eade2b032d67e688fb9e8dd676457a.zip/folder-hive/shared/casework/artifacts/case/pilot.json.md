---
seed_file: templates/casework/work/starter/case/pilot.json
seed_sha256: 53602cb734cab4d50e7a00dd46ddbc085563c40ce6d374c86312629f350875a0
---

```
{
  "schema": "studio-case/1",
  "case": "pilot-websocket-short",
  "deliverable": {
    "format": "vertical short",
    "width": 1080,
    "height": 1920,
    "fps": 30,
    "codec": "h264",
    "duration_s": { "min": 30, "max": 45 },
    "platforms": ["YouTube Shorts", "Instagram Reels", "TikTok"],
    "publish": false
  },
  "source": {
    "script": "source/script.md",
    "claims": "source/claims.json",
    "corpus": "source/corpus.json",
    "reference_timing": "source/reference-words.json",
    "options": [
      {
        "id": "talking-head",
        "take": "One or two presenters read the script to camera: vertical 1080x1920, 30 fps, eyes in the upper third, clean close-mic audio, no music under the voice.",
        "layout": "face in the kit's face zone; overlays use the empty space around it"
      },
      {
        "id": "synthesized",
        "take": "Synthesize the two voices locally from the script with a voice whose licence allows publication, then build a faceless layout.",
        "layout": "a framed card (waveform, title or b-roll) takes the face zone's place; overlays frame it and never cover it"
      }
    ],
    "consent": "Record only people who agreed to appear, and keep their written consent with the production."
  },
  "edit": {
    "hook": "Open on the question: How did web pages get live updates before WebSockets?",
    "target_s": 40,
    "must_show": [
      "the Upgrade request typed out live (GET /chat HTTP/1.1, Host, Upgrade: websocket, Connection: Upgrade, Sec-WebSocket-Key, Sec-WebSocket-Version: 13)",
      "the server answer 101 Switching Protocols with Sec-WebSocket-Accept, as an animated UI panel"
    ],
    "optional_trim": "If the take runs long, the board may drop the 'Any other status code' line."
  },
  "brand_kit": "brand/tokens.json",
  "gates": ["board approval (Showrunner)", "final cut (Showrunner)", "release (owner only)"],
  "classification": "public-synthetic"
}
```
