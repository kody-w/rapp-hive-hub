# The AI Video Studio

Run a nine-team video studio behind one AI front door. Every edit follows the same loop: a word-timed transcript, a timestamped motion board approved before anything is built, HyperFrames compositions for motion graphics and captions, hard quality gates, and a release package with provenance. Technical statements come from a pinned source and a claim ledger, and a derived cut never asserts more than its source. Publication stays with the owner.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Pilot: the WebSocket handshake in 40 seconds**

Produce the studio's first vertical short (1080x1920, 30 to 45 seconds) from the provided two-voice script about how a WebSocket connection starts. Record it as a talking head or synthesize it for a faceless layout. Open on the question hook, show the HTTP Upgrade request as a live-typing window and the 101 answer as an animated UI panel, caption every spoken word in short unpunctuated phrases, keep every on-screen technical statement traceable to RFC 6455 through the claim ledger, and hand over a release-ready package. Nothing is uploaded or published.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **Showrunner's Office**: Owns the brief, routes work across the teams, presents the motion board and the final cut to the owner and records the decisions, and keeps the production board current. The owner's own AI is the front door; this office is a stage behind it, not a separate bot.
- **Brand Studio**: Owns the reusable brand kit (type, colour, zones, caption style, motion language) that every production loads by name, and folds lessons from each release back into it.
- **Transcription Desk**: Produces the word-timed transcript for every take (ElevenLabs Scribe or local Whisper), fixes names and terms, reconciles against the script, and publishes words.json as the timing truth.
- **Motion Board Room**: Plans each edit in plan mode: a timestamped motion board with the hook, cuts, every overlay beat with zone, effect, words and claim key, and the caption moves. Nothing is built until it is approved.
- **Motion Graphics Shop**: Builds the approved board as seek-safe HyperFrames compositions: hook cards, animated UI panels, live-typing windows, layer scans and punch-ins, on brand and clear of the face.
- **Captions Desk**: Turns the transcript into short unpunctuated caption phrases, places them in free space away from the face and the overlays, and keeps every caption word traceable to the transcript.
- **Explainer Lab**: Owns scripts, sources and truth: locks each script against a pinned corpus and claim ledger, records or synthesizes the take, and certifies that every cut asserts nothing new.
- **Quality Control**: Gates every cut: lint and check clean, caption trace and style, face-safe placement, hook timing, duration and loudness, claim carryover, and a contact-sheet review against the approved board.
- **Release Desk**: Renders the approved cut and packages the vertical MP4, caption file, cover frame, post copy and provenance. Prepares publication; never performs it.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
