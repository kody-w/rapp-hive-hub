---
seed_file: templates/casework/work/starter/project/ui-panel.html
seed_sha256: 831e8e4e3470eca5118ab84516484ba560cbebea479a8749a60e5e35f862d39b
---

```
<!--
  ui-panel: a real interface or response recreated as a dark panel; rows arrive as they are spoken and their check marks
  settle, then the status pill lands.
  HyperFrames sub-composition. Host it from your root index.html, for example:
    <div id="el-panel" class="scene" data-composition-id="ui-panel" data-composition-src="compositions/overlays/ui-panel.html"
         data-start="18.4" data-duration="6" data-track-index="32"></div>
  Edit CONFIG below. Times are seconds from this overlay's own start; take them from the transcript.
  Keep CONFIG.duration equal to the host's data-duration. Seek-safe: fixed-time tweens only.
  Expects GSAP at assets/vendor/gsap.min.js. For a second copy, change the composition id in both places.
-->
<template id="ui-panel-template">
  <script src="assets/vendor/gsap.min.js"></script>
  <style>
    #ui-panel-root {
      position: absolute;
      inset: 0;
      pointer-events: none;
    }
    #ui-panel-root .box {
      position: absolute;
      left: var(--zone-lower-x, 60px);
      top: var(--zone-lower-y, 1250px);
      width: var(--zone-lower-w, 870px);
      height: var(--zone-lower-h, 380px);
      box-sizing: border-box;
      padding: 28px 30px;
      border-radius: 32px;
      background: var(--ink, #0b0b0f);
      border: 3px solid var(--line, #2a2a35);
      box-shadow: 0 18px 50px rgba(0, 0, 0, 0.45);
      opacity: 0;
      pointer-events: none;
    }
    #ui-panel-root .head { display: flex; align-items: center; margin-bottom: 18px; }
    #ui-panel-root .name {
      font-family: var(--font-display, "Inter", system-ui, sans-serif);
      font-weight: 700;
      font-size: 30px;
      color: var(--paper, #f7f5f0);
    }
    #ui-panel-root .pill {
      margin-left: auto;
      padding: 12px 24px;
      border-radius: 999px;
      background: var(--pulse, #00d1b2);
      color: var(--ink, #0b0b0f);
      font-family: var(--font-display, "Inter", system-ui, sans-serif);
      font-weight: 700;
      font-size: 24px;
      opacity: 0;
    }
    #ui-panel-root .row {
      display: flex;
      align-items: center;
      gap: 18px;
      height: 64px;
      margin-top: 12px;
      padding: 0 20px;
      border-radius: 16px;
      background: var(--panel, #16161d);
      font-family: var(--font-mono, "JetBrains Mono", ui-monospace, monospace);
      font-size: 23px;
      color: var(--paper, #f7f5f0);
      white-space: nowrap;
      opacity: 0;
    }
    #ui-panel-root .check {
      flex: none;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: var(--signal, #5b4bff);
      display: grid;
      place-items: center;
      transform: scale(0.6);
    }
  </style>
  <div id="ui-panel-root" data-composition-id="ui-panel" data-width="1080" data-height="1920">
    <div class="box" data-zone="lower">
    <div class="head"><span class="name" id="ui-panel-name"></span><span class="pill" id="ui-panel-pill"></span></div>
    <div id="ui-panel-rows"></div>
  </div>
  </div>
  <script>
    (function () {
      var CONFIG = {
        duration: 6.0,
        name: "Server",
        status: "101 Switching Protocols",
        statusAt: 0.6,
        rows: [
          { text: "Upgrade: websocket", at: 1.2 },
          { text: "Connection: Upgrade", at: 1.8 },
          { text: "Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=", at: 2.6 }
        ],
        exitAt: 5.7
      };
      document.getElementById("ui-panel-name").textContent = CONFIG.name;
      document.getElementById("ui-panel-pill").textContent = CONFIG.status;
      var list = document.getElementById("ui-panel-rows");
      var tl = gsap.timeline({ paused: true });
      tl.fromTo("#ui-panel-root .box", { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, 0);
      CONFIG.rows.forEach(function (r, i) {
        var row = document.createElement("div");
        row.className = "row";
        var check = document.createElement("span");
        check.className = "check";
        check.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16"><path d="M3 8.5l3 3 7-7" stroke="#f7f5f0" stroke-width="2.5" fill="none"/></svg>';
        var label = document.createElement("span");
        label.textContent = r.text;
        row.appendChild(check);
        row.appendChild(label);
        list.appendChild(row);
        tl.fromTo(row, { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.35, ease: "power3.out" }, r.at);
        tl.fromTo(check, { scale: 0.6 }, { scale: 1, duration: 0.3, ease: "power3.out" }, r.at + 0.15);
      });
      tl.set("#ui-panel-pill", { opacity: 0, scale: 0.9, boxShadow: "0 0 0 0 rgba(0, 209, 178, 0.55)" }, 0);
      tl.to("#ui-panel-pill", { opacity: 1, scale: 1, duration: 0.35, ease: "power3.out" }, CONFIG.statusAt);
      tl.to("#ui-panel-pill", { boxShadow: "0 0 0 16px rgba(0, 209, 178, 0)", duration: 0.7, ease: "power2.out" }, CONFIG.statusAt + 0.2);
      tl.to("#ui-panel-root .box", { opacity: 0, y: 20, duration: CONFIG.duration - CONFIG.exitAt, ease: "power2.in" }, CONFIG.exitAt);
      tl.to({}, { duration: CONFIG.duration }, 0);
      window.__timelines = window.__timelines || {};
      window.__timelines["ui-panel"] = tl;
    })();
  </script>
</template>
```
