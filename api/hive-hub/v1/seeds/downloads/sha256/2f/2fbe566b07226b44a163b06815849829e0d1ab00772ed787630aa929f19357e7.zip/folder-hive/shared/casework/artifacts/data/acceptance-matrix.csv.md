---
seed_file: templates/casework/work/starter/data/acceptance-matrix.csv
seed_sha256: f8ccf0dfb37dd9c874a9f2592189a30f3b1699ecaba0dead6e3e4cf087d0e516
---

```
criterion_id,deliverable_id,field,rule,expected_json,rationale,review_owner,classification
prototype-schema,prototype-spec,schema,equals,"""pocket-queue-interface/1""",Exact versioned business-data interface,integration,SYNTHETIC
prototype-offline,prototype-spec,offline_only,equals,true,Declaration of local-only scope; not a dynamic application test,integration,SYNTHETIC
prototype-no-network,prototype-spec,network_required,equals,false,No network dependency is allowed in the proposed scope,integration,SYNTHETIC
prototype-capacity,prototype-spec,max_demo_attendees,equals,60,Frozen 60-attendee synthetic rehearsal scope,program-office,SYNTHETIC
prototype-fields,prototype-spec,record_fields,set-equals,"[""synthetic_ticket_id"",""station_code"",""joined_at""]",Exact anonymous-field allowlist; no personal identifiers,change-control,SYNTHETIC
prototype-stations,prototype-spec,station_codes,set-equals,"[""welcome"",""demo"",""closeout""]",Three explicit station values,integration,SYNTHETIC
operations-schema,operating-model,schema,equals,"""pocket-queue-operating-model/1""",Versioned operating-model artifact,acceptance-quality,SYNTHETIC
operations-interface,operating-model,interface_schema,equals,"""pocket-queue-interface/1""",Operating model must use the current prototype interface,integration,SYNTHETIC
operations-retention,operating-model,retention_minutes,integer-between,"[1,120]",Short bounded retention in the closed rehearsal,change-control,SYNTHETIC
operations-roles,operating-model,roles,set-equals,"[""greeter"",""queue-steward"",""closeout-reviewer""]",All three distinct handoff roles are required,program-office,SYNTHETIC
operations-stop,operating-model,stop_condition,text-min-length,24,A concrete stop/escalation instruction must exist,acceptance-quality,SYNTHETIC
kit-schema,pilot-kit,schema,equals,"""pocket-queue-pilot-kit/1""",Versioned operator-kit artifact,acceptance-quality,SYNTHETIC
kit-interface,pilot-kit,interface_schema,equals,"""pocket-queue-interface/1""",Operator kit cannot refer to an obsolete interface,integration,SYNTHETIC
kit-steps,pilot-kit,operator_steps,nonempty-strings-min,4,At least four unique nonempty operator steps,acceptance-quality,SYNTHETIC
kit-no-public-launch,pilot-kit,public_launch,equals,false,Closed exercise is not a public launch,program-office,SYNTHETIC
kit-owner-review,pilot-kit,owner_review_required,equals,true,Content pass is not use or publication authority,change-control,SYNTHETIC
kit-disclosure,pilot-kit,disclosure,contains-text,"""SYNTHETIC""",The kit must visibly disclose the fictional exercise,acceptance-quality,SYNTHETIC
integration-dependencies,integration-report,all_upstreams_content_pass,equals,true,The derived report requires every upstream content gate,acceptance-quality,SYNTHETIC
```
