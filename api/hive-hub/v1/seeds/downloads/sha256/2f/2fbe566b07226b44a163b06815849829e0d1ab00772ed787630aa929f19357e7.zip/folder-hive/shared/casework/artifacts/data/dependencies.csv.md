---
seed_file: templates/casework/work/starter/data/dependencies.csv
seed_sha256: 2210f3ad5c85f100147675a2524d633be5032345eedbfb98f6045f32147fc712
---

```
deliverable_id,depends_on,interface_reason,classification
operating-model,prototype-spec,Roles and retention are built around the exact prototype interface,SYNTHETIC
pilot-kit,prototype-spec,Operator steps must name the exact data interface,SYNTHETIC
pilot-kit,operating-model,Operator guidance depends on reviewed roles and retention,SYNTHETIC
integration-report,prototype-spec,Prime requires compatible prototype content,SYNTHETIC
integration-report,operating-model,Prime requires compatible operating-model content,SYNTHETIC
integration-report,pilot-kit,Prime requires compatible pilot-kit content,SYNTHETIC
```
