# Partner Discovery and Briefs

Role: partner-brief-editor

Prepare bounded discovery-only briefs for three candidate organizations without outreach, contracts, or workspace registration.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
