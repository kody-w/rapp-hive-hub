# Case acceptance

- Each of the three candidate organizations has a concrete machine-readable brief, scoped deliverable, dependency, and review gate.
- The local matrix checks eighteen criteria across three reference artifacts and one derived integration report.
- The baseline rejects the 1440-minute retention setting and the incompatible pilot-kit interface version, and blocks the integration report.
- The corrected fixture passes content checks but still reports no exchange approval, contract, membership, workspace registration, federation activation, delivery authority, or real partner acceptance.
- Only separately owner-approved public artifacts may cross independent organizations; this package performs no crossing or remote operation.

No reference artifact counts as completed work without review.
