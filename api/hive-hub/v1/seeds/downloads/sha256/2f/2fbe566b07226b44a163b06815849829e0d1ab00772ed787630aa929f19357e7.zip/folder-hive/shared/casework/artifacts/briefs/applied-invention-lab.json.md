---
seed_file: templates/casework/work/starter/briefs/applied-invention-lab.json
seed_sha256: 47e957c699dfacec3035522f49c298b45daa58dcccecaa932cefee4f3518dfdf
---

```
{
  "schema":"synthetic-candidate-partner-brief/1",
  "classification":"SYNTHETIC",
  "brief_id":"prototype-discovery",
  "candidate_organization":"applied-invention-lab",
  "relationship":"discovery-only",
  "request_state":"unsent-and-unapproved",
  "objective":"Propose a device-free offline queue prototype interface for a closed 60-synthetic-attendee maker-hall rehearsal.",
  "in_scope":["anonymous synthetic ticket creation","three station codes","local-only behavior declaration","bounded capacity and state model","known limitations"],
  "out_of_scope":["hardware procurement","real identities","payments","network service","foreign workspace registration","production deployment"],
  "deliverable":{"id":"prototype-spec","artifact_kind":"prototype","required_fields":["schema","offline_only","network_required","max_demo_attendees","record_fields","station_codes"]},
  "depends_on":[],
  "acceptance_ids":["prototype-schema","prototype-offline","prototype-no-network","prototype-capacity","prototype-fields","prototype-stations"],
  "handoff":"An eventual separately owner-approved public artifact could be reviewed against interfaces/pilot.json. No transfer or partner work is performed by this seed.",
  "authority":{"contract":false,"membership":false,"remote_execution":false,"workspace_registration":false}
}
```
