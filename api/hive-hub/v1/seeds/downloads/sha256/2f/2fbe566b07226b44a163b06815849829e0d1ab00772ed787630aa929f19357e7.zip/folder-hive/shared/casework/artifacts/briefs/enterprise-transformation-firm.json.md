---
seed_file: templates/casework/work/starter/briefs/enterprise-transformation-firm.json
seed_sha256: 9f8bc59282fdba87dbe9bc8297e6e0cb591663bced9dce549361cebbfebc4686
---

```
{
  "schema":"synthetic-candidate-partner-brief/1",
  "classification":"SYNTHETIC",
  "brief_id":"operating-model-discovery",
  "candidate_organization":"enterprise-transformation-firm",
  "relationship":"discovery-only",
  "request_state":"unsent-and-unapproved",
  "objective":"Propose the operating model around the agreed anonymous offline ticket interface, including role handoffs and a 120-minute retention ceiling.",
  "in_scope":["greeter role","queue-steward role","closeout-reviewer role","stop/escalation condition","short retention and deletion review","operator fallback plan"],
  "out_of_scope":["real workforce changes","access administration","customer data import","live process rollout","foreign workspace registration"],
  "deliverable":{"id":"operating-model","artifact_kind":"operating-model","required_fields":["schema","interface_schema","retention_minutes","roles","stop_condition"]},
  "depends_on":["prototype-spec"],
  "acceptance_ids":["operations-schema","operations-interface","operations-retention","operations-roles","operations-stop"],
  "handoff":"Only a separately owner-approved public artifact may cross independent organization boundaries; this unsent brief creates no exchange approval.",
  "authority":{"contract":false,"membership":false,"remote_execution":false,"workspace_registration":false}
}
```
