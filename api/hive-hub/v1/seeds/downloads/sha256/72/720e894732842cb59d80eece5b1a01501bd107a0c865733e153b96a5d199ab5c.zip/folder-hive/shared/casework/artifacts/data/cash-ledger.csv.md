---
seed_file: templates/casework/work/starter/data/cash-ledger.csv
seed_sha256: 17728ba9a34df12dcd0997dad08ec922babc3d6d504c2e47e1ab0ac3aad69d8e
---

```
transaction_id,posted_on,category,direction,amount_usd,classification
cash-jul-receipts,2026-07-31,subscription-receipts,in,18000.00,SYNTHETIC
cash-jul-payroll,2026-07-28,payroll,out,17000.00,SYNTHETIC
cash-jul-contractors,2026-07-29,contractors,out,3000.00,SYNTHETIC
cash-jul-hosting,2026-07-30,hosting,out,1200.00,SYNTHETIC
cash-jul-refunds,2026-07-31,refunds,out,800.00,SYNTHETIC
cash-aug-receipts,2026-08-31,subscription-receipts,in,16000.00,SYNTHETIC
cash-aug-payroll,2026-08-28,payroll,out,17000.00,SYNTHETIC
cash-aug-contractors,2026-08-29,contractors,out,3000.00,SYNTHETIC
cash-aug-hosting,2026-08-30,hosting,out,1400.00,SYNTHETIC
cash-aug-refunds,2026-08-31,refunds,out,1200.00,SYNTHETIC
cash-sep-receipts,2026-09-30,subscription-receipts,in,14500.00,SYNTHETIC
cash-sep-payroll,2026-09-28,payroll,out,17000.00,SYNTHETIC
cash-sep-contractors,2026-09-29,contractors,out,3000.00,SYNTHETIC
cash-sep-hosting,2026-09-30,hosting,out,1800.00,SYNTHETIC
cash-sep-refunds,2026-09-30,refunds,out,1700.00,SYNTHETIC
```
