---
seed_file: templates/casework/work/starter/reference/expected-baseline.json
seed_sha256: da83816eddb917c66258c6800b2a7f73255dd149f0b7dc3c2d6f42ccf51272a5
---

```
{
  "classification": "SYNTHETIC",
  "artifact_kind": "expected-reference-counts-not-physical-results",
  "scenarios": {
    "order-trap": {"item_count": 4, "lower_bound": 2, "input-first-fit": 3, "dominant-first-fit": 2, "volume-first-fit": 2, "model_optimum": 2},
    "weight-trap": {"item_count": 8, "lower_bound": 4, "input-first-fit": 4, "dominant-first-fit": 4, "volume-first-fit": 5, "model_optimum": 4},
    "mixed-classroom": {"item_count": 14, "lower_bound": 6, "input-first-fit": 6, "dominant-first-fit": 7, "volume-first-fit": 8, "model_optimum": 6},
    "bulky-gaps": {"item_count": 3, "lower_bound": 2, "input-first-fit": 3, "dominant-first-fit": 3, "volume-first-fit": 3, "model_optimum": 3}
  }
}
```
