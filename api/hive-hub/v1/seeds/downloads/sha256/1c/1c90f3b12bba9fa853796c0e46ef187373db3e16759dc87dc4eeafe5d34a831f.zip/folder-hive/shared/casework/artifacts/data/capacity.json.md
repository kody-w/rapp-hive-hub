---
seed_file: templates/casework/work/starter/data/capacity.json
seed_sha256: 7545ddbec5d31256cab78aedcecd12777fc916de2cbded4607ccdcefcf6a6ad9
---

```
{
  "classification": "SYNTHETIC",
  "volume_units": 10,
  "weight_units": 10,
  "max_items_per_scenario": 60,
  "exact_item_limit": 12,
  "exact_node_limit": 50000,
  "interpretation": "Abstract positive integer capacities only; not physical dimensions, mass, container strength, or safe handling limits."
}
```
