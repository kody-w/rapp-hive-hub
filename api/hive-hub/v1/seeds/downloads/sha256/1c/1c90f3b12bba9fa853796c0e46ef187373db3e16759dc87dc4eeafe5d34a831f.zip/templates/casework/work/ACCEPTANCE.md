# Case acceptance

- Every item instance appears exactly once and every modeled tote respects both integer capacity constraints.
- The authored baseline reproduces all four expected scenario counts, including a case where the dominant heuristic is worse than input order.
- Seeded permutation experiments preserve all trials and can be rerun with matching source hashes and results.
- Lower-bound proofs, bounded search, unproven results, and skipped search are clearly distinguished.
- Physical fit, operator usefulness, cost, novelty, and customer demand remain unmeasured until separately approved studies occur.

No reference artifact counts as completed work without review.
