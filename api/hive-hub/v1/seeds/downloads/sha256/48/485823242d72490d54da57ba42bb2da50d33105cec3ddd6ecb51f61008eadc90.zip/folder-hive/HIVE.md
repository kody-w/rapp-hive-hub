---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The Product Launch Company

A folder-Hive template made from the RAPP Hive Hub starter `product-launch-company`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[product-launch-company]]
- First case: [[agenda-pocket-first-launch]]
- Rooms: `shared/product-strategy/`, `shared/design/`, `shared/engineering/`, `shared/creative/`, `shared/distribution/`, `shared/customer-success/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
