---
seed_file: templates/casework/work/starter/demo/styles.css
seed_sha256: 4c10f6ac582cb25d66ccb613bad6938d19547d79a732f99d2d110604a6159d35
---

```
:root {
  color-scheme: light;
  --ink: #172b2b;
  --muted: #405858;
  --paper: #f5f7f2;
  --line: #bac9c4;
  --accent: #075e55;
}
* { box-sizing: border-box; }
body { margin: 0; background: var(--paper); color: var(--ink); font: 1rem/1.55 system-ui, sans-serif; }
.hero, .layout, footer { width: min(1180px, 100% - 2rem); margin-inline: auto; }
.hero { padding-block: 2.5rem 1.5rem; max-width: 1180px; }
.eyebrow { letter-spacing: .09em; text-transform: uppercase; font-size: .8rem; font-weight: 750; }
h1 { font-size: clamp(2rem, 5vw, 3.5rem); line-height: 1.1; max-width: 22ch; margin-block: .6rem 1rem; }
h2 { margin-top: 0; font-size: 1.35rem; }
h3 { font-size: 1.05rem; }
.hero > p { max-width: 78ch; }
.boundary, .small { color: var(--muted); font-size: .9rem; }
.layout { display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr); gap: 1.2rem; align-items: start; }
.panel { background: white; border: 1px solid var(--line); border-radius: .8rem; padding: 1.3rem; min-width: 0; }
label { display: block; font-weight: 650; margin-bottom: .25rem; }
input, button { font: inherit; }
input[type="text"], input[type="number"], input[type="time"] { width: 100%; min-height: 2.7rem; padding: .5rem; border: 1px solid #647b73; border-radius: .3rem; background: white; color: var(--ink); }
input[type="checkbox"] { width: 1.1rem; height: 1.1rem; vertical-align: middle; accent-color: var(--accent); }
input[type="file"] { max-width: 100%; font-size: .85rem; }
button { padding: .65rem .9rem; border-radius: .4rem; border: 2px solid var(--accent); background: var(--accent); color: white; font-weight: 700; cursor: pointer; }
button.secondary { background: white; color: var(--accent); }
button:disabled { opacity: .55; cursor: not-allowed; }
button.remove { font-size: .8rem; padding: .35rem .5rem; }
:focus-visible { outline: 3px solid #8a3b00; outline-offset: 3px; }
.toolbar { display: flex; gap: .7rem; flex-wrap: wrap; align-items: center; margin-block: 1rem; }
.import-label { font-size: .85rem; max-width: 100%; }
.time-fields { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: .7rem; margin: 1.2rem 0; padding: .8rem; border: 1px solid var(--line); border-radius: .3rem; }
legend { font-size: .9rem; font-weight: 700; padding-inline: .25rem; }
ol { margin: 0; padding-left: 1.3rem; }
.topic-editor { padding: .7rem 0; border-top: 1px solid var(--line); }
.topic-fields { display: grid; grid-template-columns: minmax(0, 1fr) 6rem; gap: .65rem; align-items: end; }
.topic-controls { display: flex; justify-content: space-between; gap: .5rem; align-items: center; margin-top: .6rem; }
.topic-controls label { font-size: .9rem; margin: 0; }
.error { background: #fff3e4; border-left: 4px solid #864400; padding: .9rem; margin-block: 1rem; }
.blocked { border-left: 4px solid #864400; padding-left: .8rem; font-weight: 700; }
.ready { border-left: 4px solid var(--accent); padding-left: .8rem; font-weight: 700; }
.metric { margin-block: .35rem; }
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: .88rem; margin-block: 1rem; }
caption { text-align: left; font-weight: 700; margin-bottom: .4rem; }
th, td { padding: .5rem .35rem; border-bottom: 1px solid var(--line); text-align: left; vertical-align: top; overflow-wrap: anywhere; }
th { background: #edf3f0; }
.parked-list { padding-left: 1.2rem; }
.parked-list li { margin-block: .45rem; }
footer { padding-block: 2rem; color: var(--muted); font-size: .9rem; }
.skip-link { position: absolute; left: 1rem; top: -5rem; padding: .5rem; background: white; color: var(--accent); z-index: 2; }
.skip-link:focus { top: .5rem; }
[hidden] { display: none !important; }
@media (max-width: 850px) { .layout { grid-template-columns: 1fr; } }
@media (max-width: 420px) {
  .panel { padding: .85rem; }
  .time-fields { grid-template-columns: 1fr; }
  .topic-fields { grid-template-columns: 1fr; }
  .topic-controls { align-items: start; flex-wrap: wrap; }
}
@media print {
  .hero { padding-top: 0; }
  .layout { display: block; }
  .layout > section:first-child, button, .skip-link { display: none; }
  .panel { border: none; padding: 0; }
  body { background: white; }
}
```
