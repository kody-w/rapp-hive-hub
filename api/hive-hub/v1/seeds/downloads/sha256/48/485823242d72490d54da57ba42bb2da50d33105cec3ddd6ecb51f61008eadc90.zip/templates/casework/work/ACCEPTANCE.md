# Case acceptance

- The local demo operates without a server, install, CDN, account, network request, or automatic persistence.
- The sample schedules 53 topic-minutes, parks the 15-minute optional template demo, leaves two slack minutes, and reserves 09:55–10:00 for wrap.
- If required topics exceed capacity, no partial schedule is presented as feasible.
- Automated numerical cases and separately observed manual interaction checks are distinguished.
- Copy, support, storyboard, and launch decisions make no fabricated adoption or generated-video claims.

No reference artifact counts as completed work without review.
