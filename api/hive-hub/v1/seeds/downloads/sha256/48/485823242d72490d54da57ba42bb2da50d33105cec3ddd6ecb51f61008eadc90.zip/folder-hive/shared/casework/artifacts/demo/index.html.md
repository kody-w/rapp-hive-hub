---
seed_file: templates/casework/work/starter/demo/index.html
seed_sha256: 515327d7fc2e589ace20cc24d41126740c20359c8b3ff48ed82109e7abe470d5
---

```
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <title>Agenda Pocket — offline reference demo</title>
  <link rel="stylesheet" href="styles.css">
  <script src="core.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#planner">Skip to planner</a>
  <header class="hero">
    <p class="eyebrow">Agenda Pocket · original offline reference</p>
    <h1>Make room for the decisions that matter.</h1>
    <p>Reserve required topics and a wrap. See what fits, what does not, and why.</p>
    <p class="boundary">No account. No application network calls. No automatic saving.
      The supplied meeting is <strong>SYNTHETIC</strong>, not a customer story.</p>
  </header>
  <main id="planner" class="layout">
    <section class="panel" aria-labelledby="editor-heading">
      <h2 id="editor-heading">1. Shape the agenda</h2>
      <div class="toolbar">
        <button id="load-sample" type="button" class="secondary">Load synthetic example</button>
        <label class="import-label" for="import-file">Import source JSON
          <input id="import-file" type="file" accept=".json,application/json">
        </label>
      </div>
      <p id="classification" class="small"></p>
      <div id="error-summary" class="error" role="alert" tabindex="-1" hidden></div>
      <form id="agenda-form">
        <label for="agenda-title">Agenda title</label>
        <input id="agenda-title" type="text" maxlength="120" required>
        <fieldset class="time-fields">
          <legend>Same-day time budget</legend>
          <div><label for="start">Start</label><input id="start" type="time" required></div>
          <div><label for="duration">Session minutes</label><input id="duration" type="number" min="1" max="480" step="1" required></div>
          <div><label for="wrap">Wrap minutes</label><input id="wrap" type="number" min="0" max="480" step="1" required></div>
        </fieldset>
        <h3>Topics, in the order you want them</h3>
        <p id="topic-help" class="small">Required topics are never silently dropped. Optional topics fit in entry order, not by an importance score.</p>
        <ol id="topic-list" aria-describedby="topic-help"></ol>
        <div class="toolbar">
          <button id="add-topic" type="button" class="secondary">Add topic</button>
          <button type="submit">Build agenda</button>
        </div>
      </form>
    </section>
    <section class="panel result-panel" aria-labelledby="result-heading">
      <h2 id="result-heading">2. Review the tradeoff</h2>
      <p id="result-status" role="status" aria-live="polite">Build an agenda to see its time budget.</p>
      <div id="result"></div>
      <button id="export-plan" type="button" class="secondary" disabled>Export plan JSON</button>
      <p class="small">Export is a result report, not an editable source agenda. Reloading discards unsaved edits. Nothing is exported until you choose.</p>
    </section>
  </main>
  <footer>
    <p><strong>Know the limits.</strong> Whole minutes, one day, up to 50 topics.
      No calendars, time zones, collaboration, AI, tracking, or guaranteed meeting outcomes.</p>
    <p>This is a usable reference demo. Public launch, user research, and a video are not claimed.</p>
  </footer>
  <noscript><p class="error">This local demo needs JavaScript enabled. It does not need an internet connection.</p></noscript>
</body>
</html>
```
