# Integration

Role: Consensus integration

Build the consensus features as one coherent change on a fresh branch from the integration head, reconciling the source commits where they meet and leaving minority work out.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
