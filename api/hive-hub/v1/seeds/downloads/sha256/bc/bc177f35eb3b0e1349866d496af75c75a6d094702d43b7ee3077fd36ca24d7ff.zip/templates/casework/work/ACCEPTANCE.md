# Case acceptance

- The baseline is recorded at the integration head after the hermetic fix, every verify command passes, and no application data is written into the real home or any other protected path.
- Eight never-reused strategies run in separate worktrees and branches, and all eight reports follow the fixed format with evidence, a Top 3, a candidate ledger, and commits the kit verified on each strategist's branch.
- The tally clusters findings by the solution they require, applies the ceil((N+1)/2) majority rule, names the top 3 with majority or majority-like labels, and carries every unselected finding into the recurring table.
- The integration is re-verified independently at its exact commit and the protected-path audit is clean before the integration branch is fast-forwarded; record then adds read-only receipts, the history entry and an updated living review.
- Generation 2 is planned from the new head with the history extended and no reused strategy, and a runbook covers leaving the loop running, stopping it and resuming after an interruption.
- Nothing is represented as done without its evidence: sample reports are used only for tally practice, labeled as fixtures, and removed before a real run.

No reference artifact counts as completed work without review.
