# Strategy council

Role: Independent strategists

Eight independent strategists per generation, each applying one lens in its own worktree: discover with evidence, fix the most valuable problem, verify, commit locally and report in the fixed format.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
