# Loop orchestration

Role: Runs the loop and keeps it running

Configure the kit, drive every step of each generation, keep the loop running unattended, re-run generations interrupted by a host restart, and honor STOP.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
