# Verification and safety

Role: Independent verification and safety

Keep the bar and the boundaries: hermetic tests, the baseline, the harness firewall, protected-path audits, and independent re-verification before the integration branch moves.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
