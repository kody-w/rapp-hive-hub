---
seed_file: templates/casework/work/starter/quality/acceptance.csv
seed_sha256: 664b48a7230ee0cddbd73b4c4a08e883eb45807f0f75e30e095edda9e9820733
---

```
case_id,mode,setup,action,expected,classification
qa-start,automated,Create each of the three boards,Inspect state,One cell at D; turn zero; three unlit beacons,SYNTHETIC
qa-wall,automated,Start Loading Lane,Move left into wall,Position and turn unchanged,SYNTHETIC
qa-bridge-phase,automated,Place state adjacent to bridge at turn two,Enter bridge,Blocked with no beat consumed,SYNTHETIC
qa-bridge-exit,automated,Place state on bridge at turn two,Leave to adjacent path,Legal even though bridge is closed,SYNTHETIC
qa-wait,automated,Any playable state,Wait four times,Same location and bridge phase; four actions spent,SYNTHETIC
qa-reload,automated,Empty courier beside depot,Enter depot,Exactly one cell loaded,SYNTHETIC
qa-win,automated,Solve each board using breadth-first search,Replay solution,Three distinct delivered beacons; won true,SYNTHETIC
qa-undo,automated,Deliver the last cell then win,Undo,Winning delivery and action count restored to pre-win state,SYNTHETIC
qa-restart,automated,Make several successful moves,Restart,Initial state and empty undo history,SYNTHETIC
qa-keyboard,manual,Open local HTML and focus board,Use arrows WASD Space U Backspace R,All supported actions work without page scrolling; key repeat does not skip turns,SYNTHETIC
qa-offline,manual,Open local HTML with networking disabled,Complete a board,No unavailable remote assets or requests; game remains playable,SYNTHETIC
qa-sound,manual,Load fresh page with default checkbox,Move then opt in to sound,Initially silent; only opt-in events may tone; text always explains events,SYNTHETIC
qa-accessibility,manual,Use keyboard and a screen reader if available,Navigate controls and read status,Focus is visible and meaningful state is exposed; record untested limitations,SYNTHETIC
qa-narrow,manual,Use a 320-pixel-wide viewport,Read rules and use direction buttons,No inaccessible controls or board overflow,SYNTHETIC
```
