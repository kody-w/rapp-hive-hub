# The Independent Game Studio

Run a seven-team independent studio around Mosslight Courier, an original offline route puzzle. Turn synthetic first-session feedback into a bounded onboarding revision with playable source, readable art, opt-in sound, and reproducible regression evidence.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Mosslight Courier: make the first bridge legible**

SYNTHETIC production case: eight authored first-session records suggest confusion about four-beat bridge timing and undo. The starter game already works. Improve onboarding and readability without adding accounts, a backend, new mechanics, or an invented playtest result.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **Production**: Own the first-shift scope, review gates, and a conditional release decision without claiming a shipped product.
- **Game Design**: Specify understandable bridge, carrying, delivery, and undo rules within the existing three-board game.
- **Game Engineering**: Maintain the deterministic engine and keyboard-first offline browser build.
- **Art and Readability**: Create original high-contrast symbols and a small coherent visual asset system.
- **Audio**: Specify restrained, opt-in, locally synthesized event cues with a silent fallback.
- **Quality Assurance**: Check solvability, input handling, no-network behavior, accessibility limits, and regressions.
- **Player Research**: Separate the synthetic feedback exercise from real observations and design the next consent-based playtest.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
