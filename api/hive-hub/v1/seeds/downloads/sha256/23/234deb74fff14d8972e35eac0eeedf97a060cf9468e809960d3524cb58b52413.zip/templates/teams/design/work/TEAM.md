# Game Design

Role: game-designer

Specify understandable bridge, carrying, delivery, and undo rules within the existing three-board game.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
