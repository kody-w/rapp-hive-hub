# Case acceptance

- All three original boards are solvable by the deterministic engine and are playable with arrows or WASD, Space, U, and R.
- A release candidate opens directly from disk with no fetches, CDN, trackers, storage, server, or dependency install.
- Bridge and carrying state are conveyed by text/symbol as well as color; generated audio is off by default.
- The synthetic baseline remains five completions out of eight, with five bridge stalls; no real improvement is claimed without new observation.
- A producer records pass, rework, or hold against every supplied acceptance case before any separately approved publication.

No reference artifact counts as completed work without review.
