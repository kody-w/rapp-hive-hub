---
seed_file: templates/casework/work/starter/art/courier.svg
seed_sha256: d3ddc732db36f9ac80107d16c01a6144cc8619f58cf7f9f7daafbd497848fcd2
---

```
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" role="img" aria-labelledby="title desc">
  <title id="title">Mosslight courier</title>
  <desc id="desc">Original mint diamond courier with two eyes and a gold lantern.</desc>
  <rect width="96" height="96" rx="20" fill="#1c3429"/>
  <path d="M48 9 81 44 48 83 15 44Z" fill="#b7edac" stroke="#e9f6e4" stroke-width="3"/>
  <path d="M26 67 19 83M61 70 70 85" fill="none" stroke="#b7edac" stroke-width="6" stroke-linecap="round"/>
  <circle cx="37" cy="40" r="4" fill="#14251f"/><circle cx="57" cy="40" r="4" fill="#14251f"/>
  <path d="M40 53q8 7 16 0M67 54l12 5" fill="none" stroke="#14251f" stroke-width="3" stroke-linecap="round"/>
  <path d="M78 58v-7q0-5 5-5t5 5v7" fill="none" stroke="#f5cf71" stroke-width="3"/>
  <rect x="75" y="57" width="16" height="22" rx="4" fill="#f5cf71" stroke="#14251f" stroke-width="2"/>
  <path d="m83 61-4 8h4l-1 6 6-9h-5Z" fill="#14251f"/>
</svg>
```
