---
seed_file: templates/casework/work/starter/sources/release-notes.csv
seed_sha256: bb12ae8617a79f307aecba8c4da328737e58888bf5f556fc1da0c7199e50d4a1
---

```
record_id,published_at,title,statement,origin_group,classification
release-01,2026-09-08,Preview 0.8 enqueue,Local enqueue works after online sign-in; credentials require refresh every 24 hours.,juniper-authored,SYNTHETIC
release-02,2026-09-08,Preview 0.8 restart limitation,Starting the application after more than 24 disconnected hours is not supported in preview 0.8.,juniper-authored,SYNTHETIC
release-03,2026-09-14,Preview 0.9 roadmap,Token-independent launch is planned for 0.9; no dated release candidate or completed acceptance evidence is recorded.,juniper-authored,SYNTHETIC
release-04,2026-09-14,Export metric scope,Export remains manual; acknowledged-event durability is not covered by the current latency benchmark.,juniper-authored,SYNTHETIC
```
