---
seed_file: templates/casework/work/starter/analysis/claims.csv
seed_sha256: 194dbc94b2eb231aab4d22188c126dfd9fac1dba7a51efcd525660e395107ffc
---

```
claim_id,hypothesis_id,relationship,claim,source_refs,confidence,independence_note,classification
claim-promise,h-fully-offline,supports,An announcement promises full offline availability on 15 October,sources/announcements.csv#row=2,medium,Future-facing vendor-authored promise not test evidence,SYNTHETIC
claim-scope,h-supervised-only,supports,Later announcement narrows the near-term language to a supervised pilot,sources/announcements.csv#row=4,medium,Same origin as original promise,SYNTHETIC
claim-credential,h-fully-offline,contradicts,Current preview requires a credential refresh and blocks long-disconnected restart,sources/release-notes.csv#row=2;sources/release-notes.csv#row=3;sources/support-notices.csv#row=2,high,Three statements from one origin are not three independent confirmations,SYNTHETIC
claim-undated-fix,h-slip,supports,The token-independent fix is planned without a dated candidate,sources/release-notes.csv#row=4,medium,Absence of a date is not proof of a schedule slip,SYNTHETIC
claim-short-run,h-fully-offline,neutral,A short no-restart run demonstrates acknowledgments but not the required long restart,sources/lab-notes.csv#row=2;sources/benchmark-runs.csv#row=2,low,Same experiment appears as narrative and structured row,SYNTHETIC
claim-long-restart,h-supervised-only,supports,Two long-restart trials are blocked before the application can accept entries,sources/lab-notes.csv#row=3;sources/benchmark-runs.csv#row=3;sources/benchmark-runs.csv#row=4,medium,Two related runs share supplied hardware and build,SYNTHETIC
claim-recovery-gap,h-fully-offline,contradicts,The short restart leaves eight acknowledged IDs unreconciled in the export,sources/lab-notes.csv#row=4;sources/benchmark-runs.csv#row=5;sources/support-notices.csv#row=3,medium,Export incompleteness and actual event loss remain competing explanations,SYNTHETIC
claim-no-long-pass,h-slip,neutral,The corpus lacks a documented qualifying 72-hour pass,sources/support-notices.csv#row=4,medium,Missing evidence does not prove that a future fix cannot arrive,SYNTHETIC
claim-dependence,h-fully-offline,neutral,Lab-style notes disclose vendor-supplied devices and build,sources/lab-notes.csv#row=5,high,Origin labels do not establish experimental independence,SYNTHETIC
```
