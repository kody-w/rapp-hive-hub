---
seed_file: templates/casework/work/starter/sources/support-notices.csv
seed_sha256: 8f911383ce7552f5eef8e4f82e2b2ac35d6e0c8528379aa2869a03c7398eb01e
---

```
record_id,published_at,title,statement,origin_group,classification
support-01,2026-09-12,Credential expiry workaround,After the 24-hour credential expires an offline restart is blocked; reconnect once to refresh before continuing.,juniper-authored,SYNTHETIC
support-02,2026-09-15,Recovered entry investigation,An investigation remains open into missing recovered entries after reset; manual exports may omit recently acknowledged entries.,juniper-authored,SYNTHETIC
support-03,2026-09-17,Long-run evidence status,No documented 72-hour disconnected cold-start pass is available in the preview evidence set as of this notice.,juniper-authored,SYNTHETIC
```
