---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The Public-Source Intelligence Bureau

A folder-Hive template made from the RAPP Hive Hub starter `public-source-intelligence-bureau`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[public-source-intelligence-bureau]]
- First case: [[juniper-offline-pilot]]
- Rooms: `shared/collection/`, `shared/analysis/`, `shared/competing-hypotheses/`, `shared/verification/`, `shared/briefing/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
