---
seed_file: templates/casework/work/starter/design/desk-caddy.svg
seed_sha256: df7492b4f09e917a7b3da2daef4266a478137094caa2c95a1afb8056eb331d2d
---

```
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 172" width="720" height="516" role="img" aria-labelledby="title desc">
  <title id="title">Stackline nominal desk caddy top plan</title>
  <desc id="desc">Original 180 by 100 mm tray with 3 mm walls and a removable 171 by 91 mm ladder insert. Illustration only; not a cutting template.</desc>
  <rect width="240" height="172" fill="#f4f1e9"/>
  <g transform="translate(30 30)" stroke="#233f42" stroke-width=".6">
    <rect width="180" height="100" fill="#bcc8c7"/>
    <rect x="3" y="3" width="174" height="94" fill="#f4f1e9"/>
    <g transform="translate(4.5 4.5)" fill="#397c78">
      <rect width="171" height="2"/><rect y="89" width="171" height="2"/>
      <rect x="56" y="2" width="2" height="87"/><rect x="113" y="2" width="2" height="87"/>
    </g>
    <path d="M0-5V-13M180-5V-13M0-9H180M-5 0H-13M-5 100H-13M-9 0V100" fill="none"/>
  </g>
  <g fill="#233f42" font-family="sans-serif" font-size="6">
    <text x="120" y="17" text-anchor="middle">180 mm outer width</text>
    <text x="10" y="80" text-anchor="middle" transform="rotate(-90 10 80)">100 mm outer depth</text>
    <text x="30" y="142">Tray height 32 · floor/wall 3 · insert height 20 mm</text>
    <text x="30" y="152">1.5 mm nominal side clearance · dry lift-out assembly</text>
    <text x="30" y="162">SYNTHETIC planning reference; no physical manufacturing performed</text>
  </g>
</svg>
```
