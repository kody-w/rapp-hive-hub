# The Micro-Manufacturing Company

Coordinate industrial design, engineering, sourcing, production planning, quality, logistics, and finance around a non-safety-critical two-piece desk caddy. Trace dimensional changes through material, cost, fit, inspection, and packaging before any approved fabrication.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Stackline desk caddy: a 20-kit planning exercise**

SYNTHETIC case: a fictional micro-business is considering twenty desktop organizers consisting of a tray and removable ladder insert. A request to widen the tray from 180 to 196 mm must be evaluated against a fixed packing envelope. No object has been manufactured, sourced, purchased, inspected, or shipped.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **Industrial Design**: Own the desk-use requirements, compartment layout, and proposed width change.
- **Mechanical Engineering**: Maintain the parametric tray/insert geometry and nominal fit calculations.
- **Sourcing**: Maintain clearly synthetic material and cost assumptions without quotations, orders, or supplier claims.
- **Production Planning**: Plan a bounded pilot and manual fit sequence, without executing fabrication or specifying hazardous machinery.
- **Dimensional Quality**: Define measurements, evaluate synthetic sample rows, and hold nonconforming geometry.
- **Packaging and Logistics**: Check modeled packing dimensions, mass, labeling, and approval boundaries.
- **Unit Economics**: Reproduce material, handling, packaging, and overhead scenarios with explicit rounding and uncertainty.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
