# portfolio-go-to-market

Role: Shared go-to-market

Draft differentiated offers and approval-gated learning invitations for each unit.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
