# platform-engineering

Role: Shared engineering

Maintain the offline allocation analysis and reusable CSV preflight reference tool.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
