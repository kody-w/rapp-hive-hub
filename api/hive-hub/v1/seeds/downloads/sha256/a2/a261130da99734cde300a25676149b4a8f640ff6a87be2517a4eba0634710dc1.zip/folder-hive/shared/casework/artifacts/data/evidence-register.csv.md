---
seed_file: templates/casework/work/starter/data/evidence-register.csv
seed_sha256: 6bce712fe9f24a7057f36d105f23c62c730479a3a73d08abc4a041fb612cf761
---

```
classification,assumption-id,unit,assumption,available-evidence,disconfirming-observation
SYNTHETIC,lf-need,ledgerleaf-tools,Findings reduce import confusion,Authored reference fixture only,Reader cannot explain the duplicate-key finding
SYNTHETIC,lf-format,ledgerleaf-tools,JSON findings can support a later UI,Local schema inspection only,Finding lacks a stable row and code
SYNTHETIC,fn-need,fieldnote-guides,A guide helps people start organizing,Fictional drawer inventory only,Guide requires more setup than a plain list
SYNTHETIC,fn-format,fieldnote-guides,A single page is enough,Original outline only,Reader needs an unexplained second page
SYNTHETIC,qb-need,quietbench-templates,Field order reduces ambiguity,Synthetic field list only,Required purpose is unclear without visual layout
SYNTHETIC,qb-access,quietbench-templates,Keyboard order can be predictable,Proposed walkthrough only,Keyboard traversal differs from reading order
SYNTHETIC,rp-need,routepaper-planners,Category grouping is useful without maps,Synthetic errand list only,Grouping changes no planning decision
SYNTHETIC,rp-privacy,routepaper-planners,A useful sheet needs no addresses,Original concept only,Core feature requires collecting locations
SYNTHETIC,tl-need,tinylesson-studio,A short lesson supports transfer,Original lesson outline only,Learner only copies the sample naming pattern
SYNTHETIC,tl-scope,tinylesson-studio,Six minutes can fit one objective,Proposed timing budget only,Exercise and feedback exceed the timebox
```
