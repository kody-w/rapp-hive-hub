---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The One-Person Conglomerate

A folder-Hive template made from the RAPP Hive Hub starter `one-person-conglomerate`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[one-person-conglomerate]]
- First case: [[first-portfolio-cycle]]
- Rooms: `shared/executive-office/`, `shared/portfolio-research/`, `shared/portfolio-finance/`, `shared/platform-engineering/`, `shared/portfolio-go-to-market/`, `shared/ledgerleaf-tools/`, `shared/fieldnote-guides/`, `shared/quietbench-templates/`, `shared/routepaper-planners/`, `shared/tinylesson-studio/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
