---
seed_file: templates/casework/work/starter/data/portfolio.csv
seed_sha256: 4ad0bdec0a16139274136f8733d55672f693917906498582c54a9f0d355dcc11
---

```
classification,unit,working-name,offer-hypothesis,starter-artifact,validation-state
SYNTHETIC,ledgerleaf-tools,Ledgerleaf Tools,Explain small CSV import problems,Original offline CSV preflight,unvalidated
SYNTHETIC,fieldnote-guides,Fieldnote Guides,Make a supply-drawer reset easier to start,Original printable guide outline,unvalidated
SYNTHETIC,quietbench-templates,Quietbench Templates,Make purchasing requests easier to understand,Accessible request-form field plan,unvalidated
SYNTHETIC,routepaper-planners,Routepaper Planners,Group errands without location tracking,Category-first printable worksheet concept,unvalidated
SYNTHETIC,tinylesson-studio,Tinylesson Studio,Teach transferable file-naming habits,Six-minute lesson and assessment outline,unvalidated
```
