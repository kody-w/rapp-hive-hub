---
seed_file: templates/casework/work/starter/data/allocation-worksheet.csv
seed_sha256: 4af5c94434193d953aad94b4e88e777fc0713866109f98b78001154afe0ca3ad
---

```
classification,experiment-id,unit,hours,cost-usd,learning-points,reuse-points,confidence-pct,selected,experiment
SYNTHETIC,lf-schema,ledgerleaf-tools,8,40.00,5,5,60,1,Narrow the CSV finding contract
SYNTHETIC,lf-export,ledgerleaf-tools,10,100.00,4,1,40,0,Explore a downstream findings export
SYNTHETIC,fn-outline,fieldnote-guides,6,35.00,4,3,50,1,Create a supply-drawer guide page
SYNTHETIC,fn-observation,fieldnote-guides,8,120.00,5,1,30,0,Design a consented observation protocol
SYNTHETIC,qb-keyboard,quietbench-templates,7,20.00,4,4,65,0,Check request-form keyboard order
SYNTHETIC,qb-catalog,quietbench-templates,5,50.00,2,4,40,0,Explore three template names
SYNTHETIC,rp-sheet,routepaper-planners,5,15.00,3,3,55,1,Build one location-free errand sheet
SYNTHETIC,rp-interview,routepaper-planners,8,90.00,5,2,25,0,Design a later research invitation
SYNTHETIC,tl-sample,tinylesson-studio,6,30.00,4,4,50,0,Build one file-naming lesson
SYNTHETIC,tl-transfer,tinylesson-studio,9,80.00,5,2,30,0,Design the transfer assessment
```
