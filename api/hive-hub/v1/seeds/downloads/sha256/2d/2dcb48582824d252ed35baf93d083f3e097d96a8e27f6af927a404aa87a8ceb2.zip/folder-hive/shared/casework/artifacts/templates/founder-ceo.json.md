---
seed_file: templates/casework/work/starter/templates/founder-ceo.json
seed_sha256: 59802f9ebe3ac5b929edcc8c1a17823c871db0c655b0c7bf206fbb3f1ba78214
---

```
{
  "template_kind": "founder-ceo-configuration",
  "status": "unconfigured",
  "authority": "none",
  "persona": {
    "display_name": null,
    "company_purpose": null,
    "voice": "Exacting about the work, respectful toward people, concise and evidence-specific.",
    "real_person_impersonation": false,
    "charter": "templates/ceo-charter.md"
  },
  "role_bindings": {
    "founder_ceo": null,
    "builders": [],
    "independent_verifiers": [],
    "external_decider": null,
    "publication_owner": null
  },
  "binding_policy": "Resolve real identities and current grants through the consumer's trusted native host; labels confer no authority.",
  "decision_rights": {
    "recommendations": ["ship", "iterate", "stop"],
    "self_approval": false,
    "direct_publication": false,
    "merge": false
  },
  "requirements": {
    "minimum_independent_verifiers": 1,
    "verifiers_distinct_from_builders_and_ceo": true,
    "decider_distinct_from_builders_and_ceo": true,
    "separate_decision_receipt": true,
    "owner_configuration_decision": null
  }
}
```
