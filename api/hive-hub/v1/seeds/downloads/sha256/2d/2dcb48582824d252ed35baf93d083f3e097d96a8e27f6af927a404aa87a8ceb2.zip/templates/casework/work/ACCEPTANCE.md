# Case acceptance

- The native Organization remains pointer-only with seven same-world team Workspaces and separate casework; setup requires exact pinned SDK plans and owner approval.
- The founder-CEO persona is owner-configurable and can recommend, not self-approve, publish or merge.
- The fixed-grammar reference works offline with bounded inputs, deterministic responses, no hidden effects and no false durability claim.
- Actual chat use of the exact candidate is distinguished from unit tests and must occur before release qualification.
- Changed candidate, dependencies, support, tests or projection invalidates carried qualification and requires fresh evidence.
- Independent verifiers are distinct from builders and CEO; a separate external decision follows and binds verification and review.
- Only an owner-approved sanitized public projection with zero nested privacy findings, completed license review and passing current checks reaches a PR.
- A ready PR is not a release; completion requires observing the owner's merge of its checked head.

No reference artifact counts as completed work without review.
