---
hive:
version: 1
approvals: 2
fields: id=id; title=title; status=status; owner=owner,assignee; depends on=depends_on
---

# The Enterprise Transformation Firm

A folder-Hive template made from the RAPP Hive Hub starter `enterprise-transformation-firm`. It is not a Hive yet: `hive:` stays empty on purpose. A founder's Brainstem creates the Hive with the Hive agent, which gives it a fresh id, starts it at 2 approvals, keeps the `fields:` hint above, and signs the founder's key file into `members/`. Nothing in this folder runs.

- Charter: [[enterprise-transformation-firm]]
- First case: [[lattice-harbor-quote-pilot]]
- Rooms: `shared/account-strategy/`, `shared/discovery/`, `shared/architecture/`, `shared/engineering/`, `shared/quality/`, `shared/adoption/` and `shared/casework/`

`members/`, `requests/` and `former/` appear as people join and leave. This template holds no keys, members or real ids.
