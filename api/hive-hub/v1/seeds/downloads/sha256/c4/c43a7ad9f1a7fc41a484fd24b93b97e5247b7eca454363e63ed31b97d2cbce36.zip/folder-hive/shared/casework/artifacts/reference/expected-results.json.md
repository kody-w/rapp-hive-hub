---
seed_file: templates/casework/work/starter/reference/expected-results.json
seed_sha256: 287067af395316f7048b856ac4ceb1958c0a5a78d09898b25cbd8ffcf1f9dbfc
---

```
{
  "classification": "SYNTHETIC",
  "artifact_kind": "expected-reference-results-not-observed-business-results",
  "quotes": [
    {"quote_id": "q-101", "total_usd": "268.21", "state": "ready-for-human-approval", "data_errors": [], "review_reasons": []},
    {"quote_id": "q-102", "total_usd": "116.10", "state": "needs-review", "data_errors": [], "review_reasons": ["credit-limit"]},
    {"quote_id": "q-103", "total_usd": "208.55", "state": "needs-review", "data_errors": [], "review_reasons": ["line-103-a:discount-policy"]},
    {"quote_id": "q-104", "total_usd": "935.16", "state": "needs-review", "data_errors": [], "review_reasons": ["inactive-account", "terms-policy"]},
    {"quote_id": "q-105", "total_usd": null, "state": "needs-data", "data_errors": ["line-105-a:unknown-tax-code", "missing-po"], "review_reasons": []},
    {"quote_id": "q-106", "total_usd": "10.16", "state": "ready-for-human-approval", "data_errors": [], "review_reasons": []},
    {"quote_id": "q-107", "total_usd": null, "state": "needs-data", "data_errors": ["line-107-a:invalid-quantity"], "review_reasons": []},
    {"quote_id": "q-108", "total_usd": "107.50", "state": "needs-review", "data_errors": [], "review_reasons": ["terms-policy"]}
  ]
}
```
